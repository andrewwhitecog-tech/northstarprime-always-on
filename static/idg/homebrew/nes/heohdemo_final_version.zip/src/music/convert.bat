@echo off

path=g:\famitracker;..\tools

del *.s

call :convert_nsf m_dendy_rus
call :convert_nsf m_signal
call :convert_nsf m_title
call :convert_nsf m_vaders
call :convert_nsf m_kirby
call :convert_nsf m_greets
call :convert_nsf m_credits
call :convert_nsf m_demo
call :convert_nsf m_pacman
call :convert_nsf m_dungeon

del *.nsf

pause

exit



:convert_nsf
famitracker %~1.ftm -export %~1.nsf
nsfco %~1.nsf
exit /b 0
