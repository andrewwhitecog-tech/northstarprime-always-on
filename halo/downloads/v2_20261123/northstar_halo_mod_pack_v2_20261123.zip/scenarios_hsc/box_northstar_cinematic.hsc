; ============================================================================
; NORTHSTAR HALO 3 SCENARIO SCRIPT: box_northstar_cinematic.hsc
; Preset: Cinematic Flythrough & Weather Control (H3EK Sapien / Tool Ready)
; Tagline: NORTHSTAR AI DIRECTOR // BOX_NORTHSTAR_CINEMATIC
; ============================================================================

(global boolean g_northstar_cinematic_active FALSE)
(global short g_camera_phase 0)

(script static void ns_camera_sweep_intro
	(print "NORTHSTAR AI DIRECTOR // BOX_NORTHSTAR_CINEMATIC")
	(cinematic_start)
	(camera_control TRUE)
	(set g_northstar_cinematic_active TRUE)
	(sleep 30)
	(set g_camera_phase 1)
	(sleep 90)
	(camera_control FALSE)
	(cinematic_stop)
	(set g_northstar_cinematic_active FALSE)
)

(script startup box_northstar_cinematic_init
	(print "NorthStar H3EK Cinematic Director initialized.")
	(ns_camera_sweep_intro)
)
