# Client intake

Project ID: [ID]
Client / project: [name]
Prepared by: [name]
Date: [date]

## Requested result

What should be different when this is finished? [one concrete outcome]
Who will use the result? [audience]
What does a correct example look like? [example or reference]

## Source materials

| Filename or link | Owner / permission | Format / size | Any restrictions |
|---|---|---|---|
| [source] | [owner] | [format] | [restrictions] |

Required names, spellings, identifiers, or values that must not change: [details]
Do not include passwords, access tokens, or unnecessary personal information here.

## Schedule and communication

Requested date: [date and timezone]
Confirmed start date: [date, or awaiting agreement]
Client contact for decisions: [contact]
Preferred feedback channel: [channel]
Availability or review timing that affects delivery: [details]

## Open questions

- [Question, person responsible, and needed-by date]
