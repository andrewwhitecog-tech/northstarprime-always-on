HEOHdemo by Shiru 10'2019

 Party Version has been developed and tested using emulators only, and 
was sent to the CAFe'2019 demoparty along with FCEUX emulator. After it 
has been released to the public, a number of issues has been found while 
running it one the real hardware. Each test in a different setup 
revealed different issues, sometimes unique to a testing setup, and it 
was unclear whether to attribute it to the code issues, or test setup 
issues - some of the issues could be possibly attributed to 
imperfections of the MMC3 implementation in popular Flash cartridges, 
but some may be legit issues in the original code. After the demo was 
tested on a real MMC3 board with NTSC NES, three major issues were 
considered legit: 

- The color bars were flickering, alternating between two very different 
  scales
- Flickering lines were sometimes seen on the letters in the 
  scrolling title scene
- Mario and door sprites in the corridor scene 
  were severely corrupted 

Final Version has been made to correct all of these issues, and it runs 
on this test setup as intended, without any glitches and unstability. 
One remaining imperfection is the flickering dots in the rotating N logo 
scene just under the text string. As I don't have direct access to the 
testing setup, and sending tests back and forth through a chain of 
involved people is kinda troublesome, I decided to leave it as is. 


Mail:	 shiru@mail.ru
Web:     http://shiru.untergrund.net
Support: https://www.patreon.com/shiru8bit