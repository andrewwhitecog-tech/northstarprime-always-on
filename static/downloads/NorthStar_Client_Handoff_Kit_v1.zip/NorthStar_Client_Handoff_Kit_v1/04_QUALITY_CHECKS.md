# Delivery quality check

Project ID: [ID]
Version checked: [version]
Checked by / date: [name and date]

- [ ] Every scoped deliverable exists and is in the promised format.
- [ ] The exact delivered files open or decode successfully.
- [ ] Names, counts, dimensions, durations, or record totals match the scope.
- [ ] Required source identifiers, meaning, and permissions are preserved.
- [ ] Rejected or superseded versions are outside the delivery folder.
- [ ] Missing data and unresolved issues are described in the delivery note.
- [ ] Filenames identify the project and version without exposing unnecessary information.
- [ ] The file inventory matches the actual delivery folder.
- [ ] The recipient can understand what to review and where to respond.

## Evidence

| Check | Actual result | File or evidence reference |
|---|---|---|
| [check] | [result] | [reference] |

## Open issues

[Issue, effect on use, and next action; or None found within the stated checks]

Passing a technical check does not establish client acceptance, publication, or payment.
