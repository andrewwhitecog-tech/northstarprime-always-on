(global boolean citadel_boss_phase false)
(global real shield_harmonic 1.0)

(script startup citadel_39char_raid_init
  (begin
    (print "NORTHSTAR OMNIVERSE RAID: 8 AAL GUARDIANS & UNCLE VORATH CITADEL")
    (wake citadel_gate_sequence)
    (wake citadel_boss_check)
  )
)

(script dormant citadel_gate_sequence
  (begin
    (sleep 60)
    (object_create_anew vorath_helix_beacon)
    (ai_place sq_aal_guardian_vanguard)
    (print "8 AAL Voxel/Spartan Guardians synchronized at Citadel Gate")
  )
)

(script continuous citadel_boss_check
  (begin
    (sleep 150)
    (if (not citadel_boss_phase)
      (begin
        (set citadel_boss_phase true)
        (set shield_harmonic 0.35)
        (print "The Architect of the Null (Vorath Emperor) entered Phase 2")
      )
    )
  )
)
