; ============================================================================
; NORTHSTAR HALO 3 × VORATH × MINECRAFT SCENARIO SCRIPT: halo_vorath_ark_citadel.hsc
; Preset: Installation 00 Silent Cartographer, Spartan-117 & Covenant Scarab Director
; Tagline: FINISH THE FIGHT IN THE COSMIC IRIS // HALO × VORATH × MINECRAFT
; ============================================================================

(global boolean g_vorath_ark_portal_active TRUE)
(global boolean g_scarab_prime_engaged FALSE)
(global short g_halo_vorath_wave 0)
(global long g_chant_cadence_ticks 120)
(global real g_ring_resonance_level 1.17)

(script static void vorath_announce_ark_phase
	(print "HALO x VORATH x MINECRAFT // INSTALLATION 00 SILENT CARTOGRAPHER CITADEL")
	(set g_halo_vorath_wave (+ g_halo_vorath_wave 1))
)

(script static void vorath_activate_light_bridge
	(print "343 GUILTY SPARK ORACLE: Hardlight bridge & Vorath Cosmic Eye portal energized.")
	(set g_vorath_ark_portal_active TRUE)
)

(script dormant vorath_scarab_prime_drop
	(sleep 90)
	(print "CORTANA NEURAL LINK: Ultra-heavy Covenant Scarab walker detected on East Terrace!")
	(set g_scarab_prime_engaged TRUE)
	(game_save)
)

(script dormant vorath_spartan_arbiter_alliance
	(sleep 60)
	(print "SPARTAN-117 & THEL VADAM: Dual Energy Swords & Mark VI Mjolnir shields online.")
	(vorath_activate_light_bridge)
	(wake vorath_scarab_prime_drop)
)

(script startup halo_vorath_ark_citadel_startup
	(print "NORTHSTAR H3EK // Halo x Vorath x Minecraft Ark Citadel Director Online.")
	(vorath_announce_ark_phase)
	(wake vorath_spartan_arbiter_alliance)
)

(script continuous halo_vorath_mjolnir_heartbeat
	(sleep g_chant_cadence_ticks)
	(if g_vorath_ark_portal_active
		(begin
			(vorath_announce_ark_phase)
		)
	)
)
