# Acceptance and revision record

Project ID: [ID]
Delivered version: [version]
Delivery reference / date: [actual reference]

## Client response

Actual response date: [date]
Response reference: [message or document]
Current decision: [Awaiting response / Revision requested / Accepted / Other]

## Requested revisions

| Item | Requested change | Within agreed scope? | Owner | Due date | Resulting version |
|---|---|---|---|---|---|
| [item] | [change] | [yes/no, reason] | [name] | [date] | [version] |

## Closeout

- [ ] Final files and delivery note match the accepted version.
- [ ] The acceptance decision is backed by an actual client response.
- [ ] Outstanding obligations have an owner and date.
- [ ] Payment status is recorded separately from acceptance.
- [ ] Source retention or deletion follows the agreed project terms.

Final acceptance reference: [actual reference, or Awaiting response]
Payment status / evidence: [actual status]
Remaining actions: [details or None]

Do not convert silence, a download, or a delivery receipt into acceptance unless the actual governing agreement establishes that result.
