# Client Handoff Kit

An editable workflow for small freelance projects, by NorthStar Prime.

Start with the completed example in `07_WORKED_EXAMPLE.md`. Then copy the blank files into one folder per project and fill the bracketed fields.

1. Capture the request in `01_INTAKE.md`.
2. Agree on deliverables and limits in `02_SCOPE.md`.
3. Track changes in `03_CHANGE_REQUESTS.csv`.
4. Check the output with `04_QUALITY_CHECKS.md`.
5. Send a file inventory and review instructions from `05_DELIVERY_NOTE.md`.
6. Record feedback and the actual acceptance decision in `06_ACCEPTANCE.md`.

Markdown files are plain text. Open them in a text editor. CSV files can be imported into a spreadsheet app using comma-separated columns and text formatting for IDs. There are no macros, scripts, plugins, or required online accounts.

Use one project ID consistently. Keep originals separate from working files. Replace every bracketed field before sending a document to a customer. If a question does not apply, write `Not applicable` rather than leaving it ambiguous.

The scope worksheet records project decisions; it is not a complete service contract. This kit does not send messages, manage money, or automate a workflow.
