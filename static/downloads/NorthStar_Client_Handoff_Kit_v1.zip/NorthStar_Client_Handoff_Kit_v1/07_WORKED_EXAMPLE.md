# Worked example — fictional project

Every name and event below is invented for demonstration. This is not a testimonial or a record of paid work.

## Intake

Project: EXAMPLE-001, Cedar Example Workshop product-list cleanup.
Requested outcome: prepare a CSV for a catalog import while retaining text product IDs.
Source: `products_original.csv`, eight records and four columns; fictional customer-owned data.
Required output columns: SKU, Name, Category, Price.
Important constraint: preserve `00102` exactly; do not guess missing prices.

## Agreed scope for this example

One CSV; trim surrounding spaces, map agreed column names, and separate exact duplicate records. Deliver the cleaned copy, change log, review report, and a short readme. One revision to the stated rules. Illustrative price: $75. Example delivery target: two business days after the input and start date are confirmed.

Live shop changes and resolving conflicting prices are outside this example scope.

## Quality checks

Eight input records reconcile to seven retained records and one separately reported duplicate. The leading-zero SKU is retained. A record with a missing price appears in the review report; the value remains blank rather than being invented.

The file-opening check and record count are technical checks. They do not establish customer acceptance.

## Example delivery message

Hello Cedar Example Workshop,

Your cleaned catalog file is ready for review in the agreed delivery folder. It contains seven retained records; the separate change log identifies the one exact duplicate and the applied cleanup rules.

Please check `00102`, confirm that the columns suit your import tool, and review the blank price flagged in `review.csv`. Reply with one consolidated set of corrections or confirm that the files meet the agreed requirements.

Included: `products_cleaned.csv`, `changes.csv`, `review.csv`, and `readme.txt`.

## Example status

Delivered for review. Acceptance: awaiting response. Payment: not recorded. No sale or approval is inferred from the prepared message.
