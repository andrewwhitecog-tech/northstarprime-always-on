# SpaceCash — 11-Still Tip Pack (v01b)

**Status:** Prep for store — Creative QA CONDITIONAL PASS cleared by dropping `spacecash_banknotes_stack.jpg` (franchise-adjacent FAIL).

## Contents

11 SpaceCash stills (banknotes_stack excluded):

- `spacecash_agent_lounge.jpg`
- `spacecash_bot_bazaar.jpg`
- `spacecash_bullion_coins.jpg`
- `spacecash_courier_fleet.jpg`
- `spacecash_currency_suite.jpg`
- `spacecash_mint_bundle.jpg`
- `spacecash_mint_forge.jpg`
- `spacecash_orbital_exchange.jpg`
- `spacecash_p2p_handshake.jpg`
- `spacecash_swarm_vault.jpg`
- `spacecash_underground_node.jpg`

## Tip price

`$5` via Pay Desk — listed on https://northstarprime.net/store/

## Scope note

VORATH stills excluded. Replaced FAIL frame by drop (not swap) per Creative QA 11-still OK.
