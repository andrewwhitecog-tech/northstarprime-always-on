(global boolean convoy_active true)
(global short wave_index 1)

(script startup valhalla_northstar_director
  (begin
    (print "NORTHSTAR VALHALLA (RIVERWORLD) 16-BOT AI CONVOY & PELICAN DROP DIRECTOR")
    (ai_allegiance player human)
    (wake spawn_spartan_fireteam)
    (wake convoy_escalation_monitor)
  )
)

(script dormant spawn_spartan_fireteam
  (begin
    (sleep 45)
    (ai_place sq_northstar_spartans)
    (ai_place sq_vorath_wraith_vanguard)
    (print "Placed Spartan Fireteam & Vorath Wraith Vanguard on Riverworld")
  )
)

(script continuous convoy_escalation_monitor
  (begin
    (sleep 120)
    (if (< (ai_living_count sq_vorath_wraith_vanguard) 2)
      (begin
        (set wave_index (+ wave_index 1))
        (ai_place sq_vorath_banshee_wing)
        (print "Wave escalated: Vorath Banshee Wing deployed over Valhalla")
      )
    )
  )
)
