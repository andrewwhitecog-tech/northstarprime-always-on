.segment "PRG0"

.export _m_bgm1_dendy_rus
_m_bgm1_dendy_rus:
	.include "music/m_dendy_rus_1.s"

.export _m_bgm1_signal
_m_bgm1_signal:
	.include "music/m_signal_1.s"

.export _m_bgm1_title
_m_bgm1_title:
	.include "music/m_title_1.s"

.export _m_bgm1_vaders
_m_bgm1_vaders:
	.include "music/m_vaders_1.s"
	
.segment "PRG1"

.export _m_bgm2_kirby
_m_bgm2_kirby:
	.include "music/m_kirby_1.s"
	
.export _m_bgm2_greets
_m_bgm2_greets:
	.include "music/m_greets_1.s"
	
.segment "PRG2"

.export _m_bgm3_credits
_m_bgm3_credits:
	.include "music/m_credits_1.s"	

.export _m_bgm3_demo
_m_bgm3_demo:
	.include "music/m_demo_1.s"	

.export _m_bgm3_pacman
_m_bgm3_pacman:
	.include "music/m_pacman_1.s"	

.export _m_bgm3_dungeon
_m_bgm3_dungeon:
	.include "music/m_dungeon_1.s"	
	
.segment "PRG4"	

	.incbin "data/nescart_rotate.bin",0,16384

.segment "PRG5"	

	.incbin "data/nescart_rotate.bin",16384,16384

.segment "PRG6"	

	.incbin "data/nescart_rotate.bin",32768

.segment "PRG7"

	.incbin "data/dungeon_fwd.map"
	
.segment "PRG8"

	.incbin "data/dungeon_rot.map"

.segment "SAMPLES"
