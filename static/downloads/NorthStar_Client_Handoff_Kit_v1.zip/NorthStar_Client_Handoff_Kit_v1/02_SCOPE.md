# Project scope worksheet

Project ID: [ID]
Version: [version]
Decision date: [date]
Client: [name]
Provider: [name]

## Outcome and deliverables

Outcome: [specific result]

| Deliverable | Quantity / limit | Format | Acceptance check |
|---|---|---|---|
| [item] | [limit] | [format] | [observable check] |

## Included work

- [Specific operation and maximum size or duration]

## Outside this scope

- [Specific exclusion important to this project]

## Dependencies and dates

Client provides: [inputs]
Start condition: [all required inputs received and agreed start confirmed]
Delivery date: [date and timezone]
Feedback requested by: [date and timezone]
What happens if an input arrives late: [agreed rescheduling approach]

## Price and changes

Agreed project price / currency: [amount]
Payment milestones: [milestone, amount, and due condition]
Included revisions: [number and scope]
New requests: record them in the change tracker and agree on price/date before implementation.

## Decision record

Client agreement reference and time: [actual email/message/document reference]
Provider agreement reference and time: [actual reference]
Unresolved decisions: [details or None]

Record an agreement only after it occurs. A prepared worksheet is not an accepted order.
