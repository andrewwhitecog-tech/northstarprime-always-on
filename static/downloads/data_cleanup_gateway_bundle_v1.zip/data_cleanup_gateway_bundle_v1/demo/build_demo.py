"""Reproduce this fictional catalog-cleanup demonstration; not a generic client tool."""
from pathlib import Path
import csv
import hashlib
import json

root = Path(__file__).resolve().parent
source = root / "before.csv"
original_hash = hashlib.sha256(source.read_bytes()).hexdigest()
with source.open(encoding="utf-8", newline="") as stream:
    reader = csv.DictReader(stream)
    fields = reader.fieldnames
    rows = list(reader)
assert fields == ["sku", "name", "category", "price"]
kept, changes, review, seen = [], [], [], {}
for number, row in enumerate(rows, 1):
    clean = {key: value.strip() for key, value in row.items()}
    for key in fields:
        if row[key] != clean[key]:
            changes.append([number, "trim_surrounding_whitespace", key, row[key], clean[key]])
    signature = tuple(clean[key] for key in fields)
    if signature in seen:
        changes.append([number, "exact_duplicate_separated", "record", str(seen[signature]), ""])
        continue
    seen[signature] = number
    kept.append((number, clean))
    for key in ["sku", "name", "price"]:
        if not clean[key]:
            review.append([number, clean["sku"], "missing_" + key, "Retained unchanged; client decision needed"])
groups = {}
for number, row in kept:
    groups.setdefault(row["sku"], []).append((number, row))
for sku, group in groups.items():
    if sku and len(group) > 1:
        for number, row in group:
            review.append([number, sku, "conflicting_records_for_sku", "Both retained; no merge or price guess"])

def write(name, header, content):
    with (root / name).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(content)

write("cleaned.csv", fields, [[row[key] for key in fields] for number, row in kept])
write("changes.csv", ["source_record", "rule", "field", "before_or_first_record", "after"], changes)
write("review.csv", ["source_record", "sku", "issue", "handling"], review)
duplicates = sum(change[1] == "exact_duplicate_separated" for change in changes)
assert len(rows) == len(kept) + duplicates == 7
assert len(kept) == 6 and duplicates == 1
assert sum(row["sku"] == "00102" for number, row in kept) == 2
assert sum(item[2] == "conflicting_records_for_sku" for item in review) == 2
assert any(item[2] == "missing_name" for item in review)
assert source.read_bytes() and hashlib.sha256(source.read_bytes()).hexdigest() == original_hash
result = {"synthetic": True, "input_records": len(rows), "retained_records": len(kept),
          "exact_duplicates_separated": duplicates, "review_items": len(review),
          "source_sha256": original_hash, "original_unchanged": True,
          "leading_zero_ids_preserved": True, "conflicts_retained_for_review": True,
          "record_accounting_passed": True}
(root / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
