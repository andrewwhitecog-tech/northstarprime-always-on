# Delivery note

Subject: [Project] — [version] ready for review

Hello [name],

Your [deliverable] is ready for review at [location].

Completed: [specific result in one or two sentences]

## Included files

| Filename | Purpose | Version / size or relevant count |
|---|---|---|
| [file] | [purpose] | [details] |

## What to review

1. [The most important acceptance check]
2. [The next acceptance check]
3. [Any decision or unresolved question]

Please send one consolidated set of feedback through [channel] by [agreed date]. The scope includes [revision allowance]. If everything meets the agreed requirements, please confirm that explicitly in your reply.

Known limitations or open issues: [details or None identified within the agreed checks]

Thank you,
[name]

---
Internal completion record — remove this section from the customer message:
Exact files checked: [file list]
Sent reference and time: [complete after actual sending]
Acceptance reference: [complete after actual acceptance]
Payment status and evidence: [complete only from actual payment evidence]
