.segment "CHR00"

	.incbin "chr/dendy.chr"			;4
	.incbin "chr/bars.chr"			;4
	
.segment "CHR01"

	.incbin "chr/font.chr"			;4
	.incbin "chr/noise.chr"			;4
	
.segment "CHR02"

	.incbin "chr/vid.chr"			;4
	.incbin "chr/title.chr"			;4
	
.segment "CHR03"

	.incbin "chr/kirby_good.chr"	;8

.segment "CHR04"
	
	.incbin "chr/kirby_evil.chr"	;8
	
.segment "CHR05"

	.incbin "chr/nescart.chr"		;4
	.incbin "chr/nescart_text.chr"	;4

.segment "CHR06"

	.incbin "chr/inspired_01.chr"	;4
	.incbin "chr/inspired_02.chr"	;4

.segment "CHR07"

	.incbin "chr/inspired_03.chr"	;4
	.incbin "chr/inspired_04.chr"	;4
	
.segment "CHR08"

	.incbin "chr/inspired_05.chr"	;4
	.incbin "chr/inspired_06.chr"	;4
	
.segment "CHR09"

	.incbin "chr/inspired_07.chr"	;4
	.incbin "chr/inspired_08.chr"	;4
	
.segment "CHR0A"

	.incbin "chr/inspired_09.chr"	;4
	.incbin "chr/inspired_10.chr"	;4
	
.segment "CHR0B"

	.incbin "chr/inspired_11.chr"	;4
	.incbin "chr/inspired_12.chr"	;4
	
.segment "CHR0C"

	.incbin "chr/inspired_13.chr"	;4
	.incbin "chr/inspired_14.chr"	;4
	
.segment "CHR0D"

	.incbin "chr/inspired_15.chr"	;4
	.incbin "chr/inspired_16.chr"	;4
	
.segment "CHR0E"

	.incbin "chr/greets.chr"		;4
	.incbin "chr/vaders.chr"		;4

.segment "CHR0F"

	.incbin "chr/pacman.chr"		;4
	
.segment "CHR10"

	.incbin "chr/tower_texture_1.chr",0*512,512
	.incbin "chr/tower_texture_2.chr",0*512,512
	.incbin "chr/tower_texture_1.chr",1*512,512
	.incbin "chr/tower_texture_2.chr",1*512,512
	.incbin "chr/tower_texture_1.chr",2*512,512
	.incbin "chr/tower_texture_2.chr",2*512,512
	.incbin "chr/tower_texture_1.chr",3*512,512
	.incbin "chr/tower_texture_2.chr",3*512,512
	.incbin "chr/tower_texture_1.chr",4*512,512
	.incbin "chr/tower_texture_2.chr",4*512,512
	.incbin "chr/tower_texture_1.chr",5*512,512
	.incbin "chr/tower_texture_2.chr",5*512,512
	.incbin "chr/tower_texture_1.chr",6*512,512
	.incbin "chr/tower_texture_2.chr",6*512,512
	.incbin "chr/tower_texture_1.chr",7*512,512
	.incbin "chr/tower_texture_2.chr",7*512,512

.segment "CHR11"

	.incbin "chr/tower_texture_1.chr",8*512,512
	.incbin "chr/tower_texture_2.chr",8*512,512
	.incbin "chr/tower_texture_1.chr",9*512,512
	.incbin "chr/tower_texture_2.chr",9*512,512
	.incbin "chr/tower_texture_1.chr",10*512,512
	.incbin "chr/tower_texture_2.chr",10*512,512
	.incbin "chr/tower_texture_1.chr",11*512,512
	.incbin "chr/tower_texture_2.chr",11*512,512
	.incbin "chr/tower_texture_1.chr",12*512,512
	.incbin "chr/tower_texture_2.chr",12*512,512
	.incbin "chr/tower_texture_1.chr",13*512,512
	.incbin "chr/tower_texture_2.chr",13*512,512
	.incbin "chr/tower_texture_1.chr",14*512,512
	.incbin "chr/tower_texture_2.chr",14*512,512
	.incbin "chr/tower_texture_1.chr",15*512,512
	.incbin "chr/tower_texture_2.chr",15*512,512
	
.segment "CHR12"

	.incbin "chr/tower_texture_3.chr",0*512,512
	.incbin "chr/tower_texture_3.chr",15*512,512
	.incbin "chr/tower_texture_3.chr",1*512,512
	.incbin "chr/tower_texture_3.chr",14*512,512
	.incbin "chr/tower_texture_3.chr",2*512,512
	.incbin "chr/tower_texture_3.chr",13*512,512
	.incbin "chr/tower_texture_3.chr",3*512,512
	.incbin "chr/tower_texture_3.chr",12*512,512
	.incbin "chr/tower_texture_3.chr",4*512,512
	.incbin "chr/tower_texture_3.chr",11*512,512
	.incbin "chr/tower_texture_3.chr",5*512,512
	.incbin "chr/tower_texture_3.chr",10*512,512
	.incbin "chr/tower_texture_3.chr",6*512,512
	.incbin "chr/tower_texture_3.chr",9*512,512
	.incbin "chr/tower_texture_3.chr",7*512,512
	.incbin "chr/tower_texture_3.chr",8*512,512
	
.segment "CHR13"

	.incbin "chr/tower_texture_3.chr",8*512,512
	.incbin "chr/tower_texture_3.chr",7*512,512
	.incbin "chr/tower_texture_3.chr",9*512,512
	.incbin "chr/tower_texture_3.chr",6*512,512
	.incbin "chr/tower_texture_3.chr",10*512,512
	.incbin "chr/tower_texture_3.chr",5*512,512
	.incbin "chr/tower_texture_3.chr",11*512,512
	.incbin "chr/tower_texture_3.chr",4*512,512
	.incbin "chr/tower_texture_3.chr",12*512,512
	.incbin "chr/tower_texture_3.chr",3*512,512
	.incbin "chr/tower_texture_3.chr",13*512,512
	.incbin "chr/tower_texture_3.chr",2*512,512
	.incbin "chr/tower_texture_3.chr",14*512,512
	.incbin "chr/tower_texture_3.chr",1*512,512
	.incbin "chr/tower_texture_3.chr",15*512,512
	.incbin "chr/tower_texture_3.chr",0*512,512
	
.segment "CHR14"

	.incbin "chr/dungeon_fwd.chr"		;4
	.incbin "chr/dungeon_rot.chr"		;4
	
.segment "CHR15"

	.incbin "chr/dungeon_sprite.chr"	;4

.segment "CHR16"

.segment "CHR17"

.segment "CHR18"

.segment "CHR19"

.segment "CHR1A"

.segment "CHR1B"

.segment "CHR1C"

.segment "CHR1D"

.segment "CHR1E"

.segment "CHR1F"
