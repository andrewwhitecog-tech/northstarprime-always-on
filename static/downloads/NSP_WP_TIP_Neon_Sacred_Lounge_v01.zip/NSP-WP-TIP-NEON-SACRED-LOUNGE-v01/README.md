# NSP-WP-TIP-NEON-SACRED-LOUNGE-v01
Tier: TIP seed · Creative QA PASS

Contents (7 image assets): wp-tip-01..07.
CDN status: HOLD; Site must re-stage before go-live.
