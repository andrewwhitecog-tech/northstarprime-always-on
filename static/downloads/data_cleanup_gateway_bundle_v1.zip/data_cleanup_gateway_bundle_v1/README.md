# Data Cleanup & CSV Restructuring Gateway Toolkit (v1.0)

A turnkey Python automation suite for professional data cleansing, schema restructuring, deduplication, and forensic change auditing.

## What's Included
1. `data_cleanup_gateway.py` — Production CLI script for automated dataset cleaning and report generation.
2. `demo/` — Complete runnable fixture (`before.csv`, `cleaned.csv`, `changes.csv`, `review.csv`, `RESULT.json`, `build_demo.py`).
3. `CSV_Cleanup_Demonstration.pdf` — Visual before-and-after demonstration report for client presentations.
4. `data_cleanup_gallery.png` — Marketing and portfolio preview graphic.

## Quick Start
Run against any CSV:
```bash
python data_cleanup_gateway.py input.csv --id-col sku --required name,price
```

Outputs produced automatically:
- `cleaned.csv`: The sanitized dataset with preserved text formatting and leading zeroes.
- `changes.csv`: Forensic audit log recording every single row modification and removed duplicate.
- `review.csv`: Client-ready exception report highlighting conflicting IDs or missing required values.
- `audit_summary.json`: Machine-readable execution metrics and verification hashes.

## Running the Included Demo
```bash
cd demo
python build_demo.py
```
