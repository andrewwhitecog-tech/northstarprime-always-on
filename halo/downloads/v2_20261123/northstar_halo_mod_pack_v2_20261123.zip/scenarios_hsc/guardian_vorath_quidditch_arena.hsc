(global boolean quidditch_match_live true)
(global short gold_team_score 0)
(global short obsidian_team_score 0)

(script startup guardian_vorath_quidditch_init
  (begin
    (print "NORTHSTAR HALO x MINECRAFT CROSS-REALM: GUARDIAN ZERO-G QUIDDITCH ARENA")
    (wake guardian_low_gravity_loop)
    (wake guardian_snitch_patrol)
  )
)

(script dormant guardian_low_gravity_loop
  (begin
    (sleep 30)
    (print "Applying Zero-G Lift Impulse & Vorath Emerald Fog Harmonics")
    (sound_impulse_start "sound\music\halo3_vorath_theme" none 1.0)
  )
)

(script continuous guardian_snitch_patrol
  (begin
    (sleep 90)
    (if quidditch_match_live
      (begin
        (set gold_team_score (+ gold_team_score 10))
        (print "Quaffle goal registered in Guardian central spire")
      )
    )
  )
)
