#!/usr/bin/env python3
"""
Data Cleanup Gateway CLI v1.0
Automated CSV normalization, deduplication, and change-audit reporting.
Part of the NorthStar Revenue Engine Toolkit.
"""

import argparse
import csv
import hashlib
import json
import os
import sys
from pathlib import Path

def clean_dataset(input_path, output_dir=None, id_col=None, required_cols=None, trim_whitespace=True):
    input_path = Path(input_path).resolve()
    if not input_path.exists():
        print(f"Error: Input file '{input_path}' not found.", file=sys.stderr)
        sys.exit(1)

    out_dir = Path(output_dir).resolve() if output_dir else input_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)

    with input_path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames
        if not fields:
            print("Error: CSV has no header row.", file=sys.stderr)
            sys.exit(1)
        rows = list(reader)

    original_hash = hashlib.sha256(input_path.read_bytes()).hexdigest()
    req_cols = [c.strip() for c in required_cols.split(",")] if required_cols else []
    
    kept = []
    changes = []
    review = []
    seen_exact = {}
    key_groups = {}

    for row_num, row in enumerate(rows, start=1):
        clean_row = {}
        for k, v in row.items():
            if trim_whitespace and v is not None:
                cleaned_val = v.strip()
                if cleaned_val != v:
                    changes.append([row_num, "trim_surrounding_whitespace", k, v, cleaned_val])
                clean_row[k] = cleaned_val
            else:
                clean_row[k] = v if v is not None else ""

        sig = tuple(clean_row[k] for k in fields)
        if sig in seen_exact:
            changes.append([row_num, "exact_duplicate_separated", "entire_row", f"First seen row {seen_exact[sig]}", ""])
            continue
        seen_exact[sig] = row_num

        kept.append((row_num, clean_row))

        # Check required columns
        for col in req_cols:
            if col in clean_row and not clean_row[col]:
                ident = clean_row.get(id_col, f"row_{row_num}") if id_col else f"row_{row_num}"
                review.append([row_num, ident, f"missing_{col}", "Missing required value; client decision needed"])

        # Group by ID if provided
        if id_col and id_col in clean_row:
            val_id = clean_row[id_col]
            if val_id:
                key_groups.setdefault(val_id, []).append((row_num, clean_row))

    # Detect conflicts for same primary key
    if id_col:
        for val_id, grp in key_groups.items():
            if len(grp) > 1:
                for r_num, _ in grp:
                    review.append([r_num, val_id, f"conflicting_records_for_{id_col}", "Multiple records for same identifier; both retained"])

    # Write output files
    clean_csv_path = out_dir / "cleaned.csv"
    changes_csv_path = out_dir / "changes.csv"
    review_csv_path = out_dir / "review.csv"
    summary_json_path = out_dir / "audit_summary.json"

    with clean_csv_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(fields)
        for _, r in kept:
            w.writerow([r[k] for k in fields])

    with changes_csv_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["source_row", "rule_applied", "field", "before_value", "after_value"])
        w.writerows(changes)

    with review_csv_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["source_row", "identifier", "issue", "recommended_action"])
        w.writerows(review)

    exact_dupes = sum(1 for c in changes if c[1] == "exact_duplicate_separated")
    summary = {
        "status": "SUCCESS",
        "source_file": str(input_path),
        "source_sha256": original_hash,
        "total_input_rows": len(rows),
        "retained_rows": len(kept),
        "exact_duplicates_separated": exact_dupes,
        "total_modifications": len(changes) - exact_dupes,
        "review_exceptions_flagged": len(review),
        "cleaned_csv": str(clean_csv_path),
        "changes_csv": str(changes_csv_path),
        "review_csv": str(review_csv_path)
    }

    with summary_json_path.open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print("=== DATA CLEANUP COMPLETED ===")
    print(f"Total input rows: {len(rows)}")
    print(f"Retained rows:    {len(kept)}")
    print(f"Duplicates:       {exact_dupes}")
    print(f"Review items:     {len(review)}")
    print(f"Cleaned dataset:  {clean_csv_path}")
    print(f"Change log:       {changes_csv_path}")
    print(f"Review log:       {review_csv_path}")
    return summary

def main():
    parser = argparse.ArgumentParser(description="Data Cleanup & CSV Restructuring Gateway Toolkit")
    parser.add_argument("input", help="Path to input CSV file")
    parser.add_argument("-o", "--output-dir", help="Output directory for cleaned and audit files")
    parser.add_argument("--id-col", help="Column name serving as primary unique identifier (e.g. sku, id, email)")
    parser.add_argument("--required", help="Comma-separated list of required column names (flags missing values)")
    args = parser.parse_args()

    clean_dataset(args.input, args.output_dir, args.id_col, args.required)

if __name__ == "__main__":
    main()
