# Fictional CSV cleanup demonstration

Run `python build_demo.py` from this folder. Python 3 is required; there are no added dependencies.

This seven-record input is invented for demonstration. The script trims surrounding whitespace, separates one exact duplicate, retains both conflicting SKU records, reports a missing name, and preserves leading zeroes. Source-record numbers count data records after the header.

`before.csv` is never overwritten. `cleaned.csv`, `changes.csv`, `review.csv`, and `RESULT.json` are repeatable generated demonstration outputs. The script intentionally handles only this known fixture. A client transformation must be adapted and checked against that client's actual schema and agreed rules.

The product IDs are text. When importing a CSV into a spreadsheet app, explicitly select text format for the SKU column; a spreadsheet's automatic number conversion can otherwise remove leading zeroes even though the CSV retains them.

This demonstration is separate from the downloadable Client Handoff Kit. The kit's worked example is a different, eight-record fictional scenario.
