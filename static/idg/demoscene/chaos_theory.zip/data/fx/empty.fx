technique Empty
{
}