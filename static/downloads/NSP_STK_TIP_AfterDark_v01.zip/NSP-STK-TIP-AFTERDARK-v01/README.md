# NSP-STK-TIP-AFTERDARK-v01
Tier: TIP · Creative QA PASS

Contents (18 image assets): sf-mature-01..17 plus `mf-mature-01-afterdark-booth-v2.jpg`.
New this fold: sf-mature-17-candy-lipstick.png (2048 PNG PASS from batch_20261002_am).

Excluded: sf-mature-06-velvet-wings, sf-mature-07-opal-knuckles, and the non-v2 booth.
CDN status: HOLD; Site must re-stage before go-live.
