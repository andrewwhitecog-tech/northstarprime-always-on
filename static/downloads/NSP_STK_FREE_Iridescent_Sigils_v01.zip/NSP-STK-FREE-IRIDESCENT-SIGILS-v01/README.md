# NSP-STK-FREE-IRIDESCENT-SIGILS-v01
Tier: FREE · Creative QA PASS

Contents (20 image assets): sf-free-01..07, sf-free-10..19, plus `_from_catalog/biker-regal-sticker-1..3.webp`.
New this fold: sf-free-18-merkaba-amulet.png + sf-free-19-portal-door.png (2048 PNG PASS from batch_20261002_am).
Scarab already covered as sf-free-17-scarab-amulet.jpg (batch 01 is cutline twin of same slot — not duplicated).

Excluded: sf-free-07-atom-eye-orb, sf-free-08-cathedral-amulet, sf-free-09-iridescent-gem-seal.
CDN status: HOLD; Site must re-stage before go-live.
