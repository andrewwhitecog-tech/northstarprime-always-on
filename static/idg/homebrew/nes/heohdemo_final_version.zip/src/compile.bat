@echo off

set name=HEOHdemo

set CC65_HOME=..\

set path=%path%;tools\;..\bin

defconv main.c neslib.h e_roll.h e_inspired.h e_dungeon.h >defines.s

ca65 crt0.s || goto done

cc65 -Oi main.c --add-source || goto done

ca65 main.s || goto done

ld65 -C mmc3.cfg -o %name%.nes crt0.o main.o runtime.lib || goto done

rem pause

goto 4

:1
g:\nesasm\nestopia\nestopia.exe g:\cc65\demoee\%name%.nes
goto done

:2
g:\nesasm\punes\punes64.exe g:\cc65\demoee\%name%.nes
goto done

:3
g:\nesasm\virtuanes097e\VirtuaNESprof.exe g:\cc65\demoee\%name%.nes
goto done

:4
%name%.nes

:0
:done

del game.s
del *.o